<?php
/**
 * Plugin Name: WP Accessibility Toolkit
 * Plugin URI: https://github.com/hyveli/wp-accessibility-toolkit
 * Description: Implements WCAG 2.1 AA accessibility best practices site-wide with one-click toggles. No overlays, real fixes only.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Kara Concepcion
 * Author URI: https://github.com/hyveli
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-accessibility-toolkit
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('WPAT_VERSION', '1.0.0');
define('WPAT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPAT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/hyveli/wp-accessibility-toolkit-dist/main/release.json',
            __FILE__,
            'wp-accessibility-toolkit'
        );
    }
}

// Activation hook
register_activation_hook(__FILE__, 'wpat_activate');
function wpat_activate() {
    // Set default options on activation
    add_option('wpat_skip_nav', true);
    add_option('wpat_focus_styles', true);
    add_option('wpat_lang_attr', true);
    flush_rewrite_rules();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wpat_deactivate');
function wpat_deactivate() {
    flush_rewrite_rules();
}

// Add admin menu (minimal for testing)
add_action('admin_menu', 'wpat_add_admin_menu');
function wpat_add_admin_menu() {
    add_menu_page(
        'Accessibility',
        'Accessibility',
        'manage_options',
        'wp-accessibility-toolkit',
        'wpat_admin_page',
        'dashicons-shield',
        30
    );
}

// Minimal admin page
function wpat_admin_page() {
    ?>
    <div class="wrap">
        <h1>WP Accessibility Toolkit</h1>
        <p>Plugin activated successfully! Version: <?php echo WPAT_VERSION; ?></p>
        <p>Update checker is active. Check for updates in Plugins → Update to test the auto-update functionality.</p>
    </div>
    <?php
}