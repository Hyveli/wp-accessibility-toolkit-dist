<?php
/**
 * Plugin Name: WP Accessibility Toolkit
 * Plugin URI: https://github.com/hyveli/wp-accessibility-toolkit
 * Description: Implements WCAG 2.1 AA accessibility best practices site-wide with one-click toggles. No overlays, real fixes only.
 * Version: 1.0.6
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Kara Concepcion
 * Author URI: https://github.com/hyveli
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-accessibility-toolkit
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('WPAT_VERSION', '1.0.6');
define('WPAT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPAT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/hyveli/wp-accessibility-toolkit-dist/main/release.json',
            __FILE__,
            'wp-accessibility-toolkit'
        );
    }
}

// Activation hook
register_activation_hook(__FILE__, 'wpat_activate');
function wpat_activate() {
    // Set default options on activation
    add_option('wpat_skip_nav', true);
    add_option('wpat_focus_styles', true);
    add_option('wpat_lang_attr', true);
    flush_rewrite_rules();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wpat_deactivate');
function wpat_deactivate() {
    flush_rewrite_rules();
}

// ============================================
// ACCESSIBILITY FEATURES
// ============================================

// Skip Navigation Link (WCAG 2.4.1 - Bypass Blocks)
add_action('wp_body_open', 'wpat_skip_navigation', 1);
function wpat_skip_navigation() {
    if (!get_option('wpat_skip_nav', true)) {
        return;
    }

    $label = 'Skip to main content';
    $target = '#main-content';

    echo '<a href="' . esc_attr($target) . '" class="wpat-skip-nav">' . esc_html($label) . '</a>';
}

// Add skip nav and focus styles CSS
add_action('wp_head', 'wpat_accessibility_styles', 1);
function wpat_accessibility_styles() {
    if (!get_option('wpat_skip_nav', true) && !get_option('wpat_focus_styles', true)) {
        return;
    }
    ?>
    <style id="wpat-a11y-styles">
        /* Skip Navigation Link */
        .wpat-skip-nav {
            position: absolute;
            top: -100%;
            left: 1rem;
            z-index: 10000;
            padding: 0.75rem 1.25rem;
            background: #000;
            color: #fff;
            text-decoration: none;
            border-radius: 0 0 4px 4px;
            font-size: 1rem;
            font-weight: 600;
        }
        .wpat-skip-nav:focus {
            top: 0;
        }

        /* Enhanced Focus Styles (WCAG 2.4.7 - Focus Visible) */
        *:focus-visible {
            outline: 3px solid #005FCC !important;
            outline-offset: 3px !important;
        }

        /* Ensure skip nav is always visible when focused */
        .wpat-skip-nav:focus-visible {
            outline: 3px solid #fff !important;
            outline-offset: 2px !important;
        }
    </style>
    <?php
}

// Add id="main-content" to main content area if it doesn't exist
add_filter('the_content', 'wpat_ensure_main_id', 1);
function wpat_ensure_main_id($content) {
    static $main_id_added = false;

    if (!$main_id_added && get_option('wpat_skip_nav', true)) {
        $content = '<div id="main-content" tabindex="-1"></div>' . $content;
        $main_id_added = true;
    }

    return $content;
}

// ============================================
// ADMIN INTERFACE
// ============================================

// Add admin menu (minimal for testing)
add_action('admin_menu', 'wpat_add_admin_menu');
function wpat_add_admin_menu() {
    add_menu_page(
        'Accessibility',
        'Accessibility',
        'manage_options',
        'wp-accessibility-toolkit',
        'wpat_admin_page',
        'dashicons-shield',
        30
    );
}

// Minimal admin page
function wpat_admin_page() {
    ?>
    <div class="wrap">
        <h1>🛡️ WP Accessibility Toolkit</h1>
        <p><strong>Version:</strong> <?php echo WPAT_VERSION; ?></p>

        <div class="card" style="max-width: 800px;">
            <h2>Active Features</h2>
            <ul style="line-height: 1.8;">
                <li>
                    <strong>✅ Skip Navigation Link</strong> (WCAG 2.4.1 - Bypass Blocks)<br>
                    <small>Allows keyboard users to skip directly to main content. Press Tab on any page to see it.</small>
                </li>
                <li>
                    <strong>✅ Enhanced Focus Styles</strong> (WCAG 2.4.7 - Focus Visible)<br>
                    <small>Visible blue outline on all interactive elements when using keyboard navigation.</small>
                </li>
            </ul>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px; background: #f0f6fc; border-left: 4px solid #005FCC;">
            <h3>🧪 Testing the Features</h3>
            <ol>
                <li><strong>Skip Nav:</strong> Press <kbd>Tab</kbd> on your homepage - a "Skip to main content" link should appear at the top</li>
                <li><strong>Focus Styles:</strong> Navigate with <kbd>Tab</kbd> - all links and buttons should show a blue outline</li>
                <li><strong>Updates:</strong> Go to Plugins → Update to test the auto-update system</li>
            </ol>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>📋 What's New in v1.0.6</h3>
            <ul>
                <li>Added skip navigation link for keyboard accessibility</li>
                <li>Added enhanced focus indicators for better visibility</li>
                <li>Improved WCAG 2.1 AA compliance</li>
            </ul>
        </div>
    </div>
    <style>
        kbd {
            background: #f4f4f4;
            border: 1px solid #ccc;
            border-radius: 3px;
            padding: 2px 6px;
            font-family: monospace;
            font-size: 0.9em;
        }
    </style>
    <?php
}