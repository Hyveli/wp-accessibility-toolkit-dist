<?php
/**
 * Plugin Name: WP Accessibility Toolkit
 * Plugin URI: https://github.com/hyveli/wp-accessibility-toolkit
 * Description: Implements WCAG 2.1 AA accessibility best practices site-wide with one-click toggles.
 * Version: 1.1.1
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Kara Concepcion
 * Author URI: https://github.com/hyveli
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-accessibility-toolkit
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('WPAT_VERSION', '1.1.1');
define('WPAT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPAT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/hyveli/wp-accessibility-toolkit-dist/main/release.json',
            __FILE__,
            'wp-accessibility-toolkit'
        );

        // Force update check if URL parameter is present
        if (isset($_GET['force_update_check']) && current_user_can('manage_options')) {
            delete_site_transient('update_plugins');
            $updateChecker->checkForUpdates();
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>✅ Update check cache cleared! WordPress will check for updates now.</p></div>';
            });
        }
    }
}

// Activation hook
register_activation_hook(__FILE__, 'wpat_activate');
function wpat_activate() {
    // Set default options on activation
    add_option('wpat_skip_nav', true);
    add_option('wpat_focus_styles', true);
    add_option('wpat_lang_attr', true);
    flush_rewrite_rules();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wpat_deactivate');
function wpat_deactivate() {
    flush_rewrite_rules();
}

// ============================================
// ACCESSIBILITY FEATURES
// ============================================

// Skip Navigation Link (WCAG 2.4.1 - Bypass Blocks)
add_action('wp_body_open', 'wpat_skip_navigation', 1);
function wpat_skip_navigation() {
    if (!get_option('wpat_skip_nav', true)) {
        return;
    }

    $label = 'Skip to main content';
    $target = '#main-content';

    echo '<a href="' . esc_attr($target) . '" class="wpat-skip-nav">' . esc_html($label) . '</a>';
}

// Add skip nav and focus styles CSS
add_action('wp_head', 'wpat_accessibility_styles', 1);
function wpat_accessibility_styles() {
    if (!get_option('wpat_skip_nav', true) && !get_option('wpat_focus_styles', true)) {
        return;
    }
    ?>
    <style id="wpat-a11y-styles">
        /* Skip Navigation Link */
        .wpat-skip-nav {
            position: absolute;
            top: -100%;
            left: 1rem;
            z-index: 10000;
            padding: 0.75rem 1.25rem;
            background: #000;
            color: #fff;
            text-decoration: none;
            border-radius: 0 0 4px 4px;
            font-size: 1rem;
            font-weight: 600;
        }
        .wpat-skip-nav:focus {
            top: 0;
        }

        /* Enhanced Focus Styles (WCAG 2.4.7 - Focus Visible) */
        *:focus-visible {
            outline: 3px solid #005FCC !important;
            outline-offset: 3px !important;
        }

        /* Ensure skip nav is always visible when focused */
        .wpat-skip-nav:focus-visible {
            outline: 3px solid #fff !important;
            outline-offset: 2px !important;
        }
    </style>
    <?php
}

// Add id="main-content" to main content area if it doesn't exist
add_filter('the_content', 'wpat_ensure_main_id', 1);
function wpat_ensure_main_id($content) {
    static $main_id_added = false;

    if (!$main_id_added && get_option('wpat_skip_nav', true)) {
        $content = '<div id="main-content" tabindex="-1"></div>' . $content;
        $main_id_added = true;
    }

    return $content;
}

// Page Titles Check (WCAG 2.4.2 - Page Titled)
add_action('wp_head', 'wpat_check_page_title', 1);
function wpat_check_page_title() {
    if (!get_option('wpat_page_titles', false)) {
        return;
    }

    // WordPress handles page titles well by default, but we can enhance
    add_filter('document_title_separator', function($sep) {
        return '|';
    });

    // Ensure title is descriptive
    add_filter('document_title_parts', function($title) {
        if (empty($title['title'])) {
            $title['title'] = get_the_title() ?: 'Untitled Page';
        }
        return $title;
    });
}

// ARIA Landmark Roles (WCAG 1.3.1 - Info and Relationships)
add_action('template_redirect', 'wpat_landmark_roles_buffer');
function wpat_landmark_roles_buffer() {
    if (!get_option('wpat_landmark_roles', false)) {
        return;
    }

    ob_start('wpat_add_landmark_roles');
}

function wpat_add_landmark_roles($html) {
    // Only process HTML responses
    if (!is_string($html) || empty($html)) {
        return $html;
    }

    // Add role attributes if missing
    $replacements = [
        '/<header(?![^>]*role=)/i' => '<header role="banner"',
        '/<main(?![^>]*role=)/i'   => '<main role="main"',
        '/<footer(?![^>]*role=)/i' => '<footer role="contentinfo"',
        '/<nav(?![^>]*role=)/i'    => '<nav role="navigation"',
    ];

    foreach ($replacements as $pattern => $replacement) {
        $html = preg_replace($pattern, $replacement, $html);
    }

    return $html;
}

add_action('shutdown', 'wpat_flush_landmark_buffer');
function wpat_flush_landmark_buffer() {
    if (get_option('wpat_landmark_roles', false) && ob_get_level() > 0) {
        ob_end_flush();
    }
}

// Heading Structure Check (WCAG 1.3.1)
add_action('wp_footer', 'wpat_check_heading_structure');
function wpat_check_heading_structure() {
    if (!get_option('wpat_heading_structure', false) || !current_user_can('manage_options')) {
        return;
    }

    // Add inline JavaScript to check heading structure (admin only)
    ?>
    <script>
    (function() {
        const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6'));
        const levels = headings.map(h => parseInt(h.tagName.substr(1)));
        let issues = [];

        // Check for multiple H1s
        const h1Count = levels.filter(l => l === 1).length;
        if (h1Count > 1) {
            issues.push('Multiple H1 tags found (' + h1Count + '). Each page should have only one H1.');
        }

        // Check for skipped levels
        for (let i = 1; i < levels.length; i++) {
            if (levels[i] - levels[i-1] > 1) {
                issues.push('Heading level skipped: H' + levels[i-1] + ' to H' + levels[i]);
            }
        }

        if (issues.length > 0 && typeof console !== 'undefined') {
            console.warn('⚠️ WP Accessibility Toolkit - Heading Structure Issues:');
            issues.forEach(issue => console.warn('  - ' + issue));
        }
    })();
    </script>
    <?php
}

// Form Labels Check (WCAG 1.3.1, 3.3.2)
add_action('wp_footer', 'wpat_check_form_labels');
function wpat_check_form_labels() {
    if (!get_option('wpat_form_labels', false) || !current_user_can('manage_options')) {
        return;
    }

    // Add inline JavaScript to check form labels (admin only)
    ?>
    <script>
    (function() {
        const inputs = document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]), textarea, select');
        let unlabeledInputs = [];

        inputs.forEach(input => {
            const hasLabel = input.labels && input.labels.length > 0;
            const hasAriaLabel = input.getAttribute('aria-label');
            const hasAriaLabelledby = input.getAttribute('aria-labelledby');
            const hasTitle = input.getAttribute('title');

            if (!hasLabel && !hasAriaLabel && !hasAriaLabelledby && !hasTitle) {
                unlabeledInputs.push(input);
            }
        });

        if (unlabeledInputs.length > 0 && typeof console !== 'undefined') {
            console.warn('⚠️ WP Accessibility Toolkit - Form Label Issues:');
            console.warn('  Found ' + unlabeledInputs.length + ' unlabeled form inputs:', unlabeledInputs);
        }
    })();
    </script>
    <?php
}

// ============================================
// ADMIN INTERFACE
// ============================================

// Add admin menu
add_action('admin_menu', 'wpat_add_admin_menu');
function wpat_add_admin_menu() {
    add_menu_page(
        'Accessibility',
        'Accessibility',
        'manage_options',
        'wp-accessibility-toolkit',
        'wpat_admin_page',
        'dashicons-shield',
        30
    );

    add_submenu_page(
        'wp-accessibility-toolkit',
        'Settings',
        'Settings',
        'manage_options',
        'wpat-settings',
        'wpat_settings_page'
    );

    add_submenu_page(
        'wp-accessibility-toolkit',
        'Compliance Scanner',
        'Scanner',
        'manage_options',
        'wpat-scanner',
        'wpat_scanner_page'
    );
}

// Register settings
add_action('admin_init', 'wpat_register_settings');
function wpat_register_settings() {
    register_setting('wpat_settings_group', 'wpat_skip_nav');
    register_setting('wpat_settings_group', 'wpat_focus_styles');
    register_setting('wpat_settings_group', 'wpat_lang_attr');
    register_setting('wpat_settings_group', 'wpat_page_titles');
    register_setting('wpat_settings_group', 'wpat_heading_structure');
    register_setting('wpat_settings_group', 'wpat_form_labels');
    register_setting('wpat_settings_group', 'wpat_landmark_roles');
}

// Dashboard page
function wpat_admin_page() {
    $active_features = array_filter([
        get_option('wpat_skip_nav', true) ? 'Skip Navigation' : null,
        get_option('wpat_focus_styles', true) ? 'Focus Styles' : null,
        get_option('wpat_lang_attr', true) ? 'Language Attribute' : null,
        get_option('wpat_page_titles', false) ? 'Page Titles' : null,
        get_option('wpat_heading_structure', false) ? 'Heading Structure' : null,
        get_option('wpat_form_labels', false) ? 'Form Labels' : null,
        get_option('wpat_landmark_roles', false) ? 'ARIA Landmarks' : null,
    ]);
    ?>
    <div class="wrap">
        <h1>🛡️ WP Accessibility Toolkit</h1>
        <p><strong>Version:</strong> <?php echo WPAT_VERSION; ?> | <strong>Compliance Level:</strong> WCAG 2.2 Level A</p>

        <div class="card" style="max-width: 800px;">
            <h2>Active Features (<?php echo count($active_features); ?>)</h2>
            <?php if (count($active_features) > 0): ?>
                <ul style="line-height: 1.8;">
                    <?php foreach ($active_features as $feature): ?>
                        <li>✅ <?php echo esc_html($feature); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No features currently enabled. Go to <a href="<?php echo admin_url('admin.php?page=wpat-settings'); ?>">Settings</a> to enable features.</p>
            <?php endif; ?>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px; background: #f0f6fc; border-left: 4px solid #005FCC;">
            <h3>🧪 Quick Start</h3>
            <ol>
                <li>Go to <a href="<?php echo admin_url('admin.php?page=wpat-settings'); ?>">Settings</a> to enable accessibility features</li>
                <li>Test skip navigation by pressing <kbd>Tab</kbd> on your homepage</li>
                <li>Navigate with keyboard to see enhanced focus indicators</li>
            </ol>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>📋 What's New in v1.1.1</h3>
            <ul>
                <li>Fixed scanner form label detection</li>
                <li>Added force update check feature (add <code>?force_update_check=1</code> to admin URL)</li>
                <li>Removed debug notices for production</li>
                <li>Improved XPath queries in compliance scanner</li>
            </ul>
        </div>
    </div>
    <style>
        kbd {
            background: #f4f4f4;
            border: 1px solid #ccc;
            border-radius: 3px;
            padding: 2px 6px;
            font-family: monospace;
            font-size: 0.9em;
        }
    </style>
    <?php
}

// Settings page
function wpat_settings_page() {
    if (isset($_POST['wpat_settings_submit'])) {
        check_admin_referer('wpat_settings_save', 'wpat_settings_nonce');

        // Save all settings
        update_option('wpat_skip_nav', isset($_POST['wpat_skip_nav']) ? 1 : 0);
        update_option('wpat_focus_styles', isset($_POST['wpat_focus_styles']) ? 1 : 0);
        update_option('wpat_lang_attr', isset($_POST['wpat_lang_attr']) ? 1 : 0);
        update_option('wpat_page_titles', isset($_POST['wpat_page_titles']) ? 1 : 0);
        update_option('wpat_heading_structure', isset($_POST['wpat_heading_structure']) ? 1 : 0);
        update_option('wpat_form_labels', isset($_POST['wpat_form_labels']) ? 1 : 0);
        update_option('wpat_landmark_roles', isset($_POST['wpat_landmark_roles']) ? 1 : 0);

        echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Accessibility Settings</h1>
        <p>Enable or disable individual WCAG 2.2 Level A compliance features.</p>

        <form method="post" action="">
            <?php wp_nonce_field('wpat_settings_save', 'wpat_settings_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpat_skip_nav">Skip Navigation Link</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_skip_nav" id="wpat_skip_nav" value="1" <?php checked(get_option('wpat_skip_nav', true)); ?>>
                            Enable skip navigation link (WCAG 2.4.1)
                        </label>
                        <p class="description">Adds a "Skip to main content" link for keyboard users. <strong>Disable if your theme already includes this.</strong></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_focus_styles">Enhanced Focus Styles</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_focus_styles" id="wpat_focus_styles" value="1" <?php checked(get_option('wpat_focus_styles', true)); ?>>
                            Enable visible focus indicators (WCAG 2.4.7)
                        </label>
                        <p class="description">Adds blue outline to all focusable elements for keyboard navigation.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_lang_attr">Language Attribute</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_lang_attr" id="wpat_lang_attr" value="1" <?php checked(get_option('wpat_lang_attr', true)); ?>>
                            Ensure HTML lang attribute (WCAG 3.1.1)
                        </label>
                        <p class="description">Ensures the &lt;html&gt; tag has a lang attribute for screen readers.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_page_titles">Page Titles</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_page_titles" id="wpat_page_titles" value="1" <?php checked(get_option('wpat_page_titles', false)); ?>>
                            Ensure descriptive page titles (WCAG 2.4.2)
                        </label>
                        <p class="description">Checks that every page has a unique &lt;title&gt; tag.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_heading_structure">Heading Structure</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_heading_structure" id="wpat_heading_structure" value="1" <?php checked(get_option('wpat_heading_structure', false)); ?>>
                            Check heading hierarchy (WCAG 1.3.1)
                        </label>
                        <p class="description">Warns if heading levels are skipped (e.g., H2 → H4).</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_form_labels">Form Labels</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_form_labels" id="wpat_form_labels" value="1" <?php checked(get_option('wpat_form_labels', false)); ?>>
                            Ensure form inputs have labels (WCAG 1.3.1, 3.3.2)
                        </label>
                        <p class="description">Checks that all form inputs have associated labels.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_landmark_roles">ARIA Landmarks</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_landmark_roles" id="wpat_landmark_roles" value="1" <?php checked(get_option('wpat_landmark_roles', false)); ?>>
                            Add ARIA landmark roles (WCAG 1.3.1)
                        </label>
                        <p class="description">Adds role attributes to &lt;header&gt;, &lt;main&gt;, &lt;footer&gt; if missing. <strong>May impact performance.</strong></p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="wpat_settings_submit" class="button button-primary" value="Save Settings">
            </p>
        </form>
    </div>
    <?php
}

// Scanner page
function wpat_scanner_page() {
    $scan_url = isset($_POST['scan_url']) ? esc_url_raw($_POST['scan_url']) : home_url();
    $scan_results = null;

    if (isset($_POST['wpat_scan_submit'])) {
        check_admin_referer('wpat_scanner_scan', 'wpat_scanner_nonce');
        $scan_results = wpat_scan_page($scan_url);
    }
    ?>
    <div class="wrap">
        <h1>WCAG 2.2 Level A Compliance Scanner</h1>
        <p>Scan any page on your site to check for WCAG 2.2 Level A compliance issues.</p>

        <div class="card" style="max-width: 1200px; background: #f0f6fc; border-left: 4px solid #005FCC;">
            <h3>📘 What This Scanner Checks</h3>
            <p>This scanner validates your pages against <strong>WCAG 2.2 Level A</strong> success criteria. Level A is the minimum level of conformance. The scanner checks:</p>
            <ul style="line-height: 1.8;">
                <li><strong>1.1.1 Non-text Content:</strong> All images must have alt attributes</li>
                <li><strong>1.3.1 Info and Relationships:</strong> Proper heading hierarchy, form labels, and semantic structure</li>
                <li><strong>2.4.1 Bypass Blocks:</strong> Skip navigation link present</li>
                <li><strong>2.4.2 Page Titled:</strong> Every page has a descriptive title</li>
                <li><strong>2.4.4 Link Purpose:</strong> Links have clear, descriptive text</li>
                <li><strong>3.1.1 Language of Page:</strong> HTML lang attribute is set</li>
                <li><strong>4.1.2 Name, Role, Value:</strong> Form controls have accessible names</li>
            </ul>
            <p><strong>Note:</strong> This is an automated scan. While it catches many common issues, a full manual audit is recommended for complete compliance assurance.</p>
        </div>

        <form method="post" action="" style="margin-top: 20px;">
            <?php wp_nonce_field('wpat_scanner_scan', 'wpat_scanner_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="scan_url">Page URL to Scan</label>
                    </th>
                    <td>
                        <input type="url" name="scan_url" id="scan_url" value="<?php echo esc_attr($scan_url); ?>" class="regular-text" required>
                        <p class="description">Enter the full URL of the page you want to scan (e.g., <?php echo home_url(); ?>)</p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="wpat_scan_submit" class="button button-primary" value="Scan Page">
            </p>
        </form>

        <?php if ($scan_results !== null): ?>
            <?php
            $total_checks = count($scan_results);
            $passed = count(array_filter($scan_results, function($r) { return $r['status'] === 'pass'; }));
            $failed = count(array_filter($scan_results, function($r) { return $r['status'] === 'fail'; }));
            $warnings = count(array_filter($scan_results, function($r) { return $r['status'] === 'warning'; }));

            $compliance_level = ($failed === 0) ? 'compliant' : 'non-compliant';
            $compliance_color = ($failed === 0) ? '#46b450' : '#dc3232';
            ?>

            <div class="card" style="max-width: 1200px; margin-top: 20px; border-left: 4px solid <?php echo $compliance_color; ?>;">
                <h2>Scan Results for: <?php echo esc_html($scan_url); ?></h2>
                <p><strong>Total Checks:</strong> <?php echo $total_checks; ?> |
                   <strong>Passed:</strong> <span style="color: #46b450;"><?php echo $passed; ?></span> |
                   <strong>Failed:</strong> <span style="color: #dc3232;"><?php echo $failed; ?></span> |
                   <strong>Warnings:</strong> <span style="color: #f56e28;"><?php echo $warnings; ?></span></p>
                <p><strong>Compliance Status:</strong>
                    <span style="color: <?php echo $compliance_color; ?>; font-weight: bold; font-size: 1.2em;">
                        <?php echo $failed === 0 ? '✅ WCAG 2.2 Level A Compliant' : '❌ Non-Compliant'; ?>
                    </span>
                </p>
            </div>

            <table class="wp-list-table widefat fixed striped" style="margin-top: 20px; max-width: 1200px;">
                <thead>
                    <tr>
                        <th width="10%">Status</th>
                        <th width="15%">WCAG Criterion</th>
                        <th width="30%">Check Description</th>
                        <th width="45%">Result / Recommendation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($scan_results as $result): ?>
                        <tr>
                            <td>
                                <?php if ($result['status'] === 'pass'): ?>
                                    <span style="color: #46b450; font-weight: bold;">✓ Pass</span>
                                <?php elseif ($result['status'] === 'fail'): ?>
                                    <span style="color: #dc3232; font-weight: bold;">✗ Fail</span>
                                <?php else: ?>
                                    <span style="color: #f56e28; font-weight: bold;">⚠ Warning</span>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo esc_html($result['wcag']); ?></strong></td>
                            <td><?php echo esc_html($result['description']); ?></td>
                            <td><?php echo esc_html($result['message']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}

// Scanner function - checks WCAG 2.2 Level A compliance
function wpat_scan_page($url) {
    $results = [];

    // Fetch the page HTML
    $response = wp_remote_get($url, ['timeout' => 15, 'sslverify' => false]);

    if (is_wp_error($response)) {
        return [['status' => 'fail', 'wcag' => 'N/A', 'description' => 'Page Load Error', 'message' => 'Could not fetch the page: ' . $response->get_error_message()]];
    }

    $html = wp_remote_retrieve_body($response);

    if (empty($html)) {
        return [['status' => 'fail', 'wcag' => 'N/A', 'description' => 'Empty Response', 'message' => 'The page returned no content.']];
    }

    // Create DOMDocument for parsing
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $dom->loadHTML($html);
    libxml_clear_errors();
    $xpath = new DOMXPath($dom);

    // 1.1.1 Non-text Content (Level A) - Images must have alt attributes
    $results[] = wpat_check_image_alts($xpath);

    // 1.3.1 Info and Relationships (Level A) - Heading hierarchy
    $results[] = wpat_check_heading_hierarchy($xpath);

    // 1.3.1 Form labels
    $results[] = wpat_check_form_labels_scan($xpath);

    // 2.4.1 Bypass Blocks (Level A) - Skip navigation
    $results[] = wpat_check_skip_nav($html);

    // 2.4.2 Page Titled (Level A)
    $results[] = wpat_check_page_title($xpath);

    // 2.4.4 Link Purpose (Level A) - Descriptive link text
    $results[] = wpat_check_link_text($xpath);

    // 3.1.1 Language of Page (Level A)
    $results[] = wpat_check_lang_attribute($html);

    // 4.1.2 Name, Role, Value (Level A) - Buttons and inputs have accessible names
    $results[] = wpat_check_button_labels($xpath);

    return $results;
}

// Individual check functions
function wpat_check_image_alts($xpath) {
    $images = $xpath->query('//img');
    $missing_alt = 0;

    foreach ($images as $img) {
        if (!$img->hasAttribute('alt')) {
            $missing_alt++;
        }
    }

    if ($missing_alt === 0) {
        return ['status' => 'pass', 'wcag' => '1.1.1 (A)', 'description' => 'Images have alt text', 'message' => 'All ' . $images->length . ' images have alt attributes.'];
    } else {
        return ['status' => 'fail', 'wcag' => '1.1.1 (A)', 'description' => 'Images have alt text', 'message' => $missing_alt . ' out of ' . $images->length . ' images are missing alt attributes.'];
    }
}

function wpat_check_heading_hierarchy($xpath) {
    $headings = $xpath->query('//h1 | //h2 | //h3 | //h4 | //h5 | //h6');
    $levels = [];

    foreach ($headings as $heading) {
        $levels[] = (int) substr($heading->tagName, 1);
    }

    // Check for multiple H1s
    $h1_count = count(array_filter($levels, function($l) { return $l === 1; }));
    if ($h1_count > 1) {
        return ['status' => 'fail', 'wcag' => '1.3.1 (A)', 'description' => 'Heading hierarchy', 'message' => 'Multiple H1 tags found (' . $h1_count . '). Pages should have only one H1.'];
    }

    if ($h1_count === 0) {
        return ['status' => 'warning', 'wcag' => '1.3.1 (A)', 'description' => 'Heading hierarchy', 'message' => 'No H1 tag found. Pages should have exactly one H1.'];
    }

    // Check for skipped levels
    for ($i = 1; $i < count($levels); $i++) {
        if ($levels[$i] - $levels[$i-1] > 1) {
            return ['status' => 'warning', 'wcag' => '1.3.1 (A)', 'description' => 'Heading hierarchy', 'message' => 'Heading levels are skipped (H' . $levels[$i-1] . ' → H' . $levels[$i] . '). Maintain sequential order.'];
        }
    }

    return ['status' => 'pass', 'wcag' => '1.3.1 (A)', 'description' => 'Heading hierarchy', 'message' => 'Proper heading structure with 1 H1 and sequential levels.'];
}

function wpat_check_form_labels_scan($xpath) {
    $inputs = $xpath->query('//input[not(@type="hidden") and not(@type="submit") and not(@type="button")] | //textarea | //select');
    $unlabeled = 0;

    foreach ($inputs as $input) {
        $input_id = $input->getAttribute('id');
        $has_label = !empty($input_id) && $xpath->query('//label[@for="' . $input_id . '"]')->length > 0;
        $has_aria = $input->hasAttribute('aria-label') || $input->hasAttribute('aria-labelledby');

        if (!$has_label && !$has_aria && !$input->hasAttribute('title')) {
            $unlabeled++;
        }
    }

    if ($inputs->length === 0) {
        return ['status' => 'pass', 'wcag' => '1.3.1 (A)', 'description' => 'Form labels', 'message' => 'No form inputs found on this page.'];
    }

    if ($unlabeled === 0) {
        return ['status' => 'pass', 'wcag' => '1.3.1 (A)', 'description' => 'Form labels', 'message' => 'All ' . $inputs->length . ' form inputs have proper labels.'];
    } else {
        return ['status' => 'fail', 'wcag' => '1.3.1 (A)', 'description' => 'Form labels', 'message' => $unlabeled . ' out of ' . $inputs->length . ' form inputs are missing labels.'];
    }
}

function wpat_check_skip_nav($html) {
    if (stripos($html, 'skip') !== false && (stripos($html, 'main content') !== false || stripos($html, 'navigation') !== false)) {
        return ['status' => 'pass', 'wcag' => '2.4.1 (A)', 'description' => 'Skip navigation', 'message' => 'Skip navigation link detected.'];
    } else {
        return ['status' => 'fail', 'wcag' => '2.4.1 (A)', 'description' => 'Skip navigation', 'message' => 'No skip navigation link found. Add a skip link for keyboard users.'];
    }
}

function wpat_check_page_title($xpath) {
    $titles = $xpath->query('//title');

    if ($titles->length === 0) {
        return ['status' => 'fail', 'wcag' => '2.4.2 (A)', 'description' => 'Page title', 'message' => 'No <title> tag found. Every page must have a descriptive title.'];
    }

    $title_text = trim($titles->item(0)->textContent);

    if (empty($title_text)) {
        return ['status' => 'fail', 'wcag' => '2.4.2 (A)', 'description' => 'Page title', 'message' => 'Page title is empty. Provide a descriptive title.'];
    }

    return ['status' => 'pass', 'wcag' => '2.4.2 (A)', 'description' => 'Page title', 'message' => 'Page has a descriptive title: "' . esc_html($title_text) . '"'];
}

function wpat_check_link_text($xpath) {
    $links = $xpath->query('//a[not(descendant::img)]');
    $vague_links = 0;
    $vague_phrases = ['click here', 'read more', 'more', 'here', 'link'];

    foreach ($links as $link) {
        $text = strtolower(trim($link->textContent));
        if (in_array($text, $vague_phrases)) {
            $vague_links++;
        }
    }

    if ($vague_links === 0) {
        return ['status' => 'pass', 'wcag' => '2.4.4 (A)', 'description' => 'Link purpose', 'message' => 'All links have descriptive text.'];
    } else {
        return ['status' => 'warning', 'wcag' => '2.4.4 (A)', 'description' => 'Link purpose', 'message' => $vague_links . ' links have vague text like "click here" or "read more". Use descriptive link text.'];
    }
}

function wpat_check_lang_attribute($html) {
    if (preg_match('/<html[^>]*\slang=["\']([^"\']+)["\'][^>]*>/i', $html, $matches)) {
        return ['status' => 'pass', 'wcag' => '3.1.1 (A)', 'description' => 'Language attribute', 'message' => 'HTML lang attribute is set to "' . esc_html($matches[1]) . '"'];
    } else {
        return ['status' => 'fail', 'wcag' => '3.1.1 (A)', 'description' => 'Language attribute', 'message' => 'HTML lang attribute is missing. Add lang="en" (or appropriate language) to <html> tag.'];
    }
}

function wpat_check_button_labels($xpath) {
    $buttons = $xpath->query('//button | //input[@type="button"] | //input[@type="submit"]');
    $unlabeled = 0;

    foreach ($buttons as $button) {
        $has_text = !empty(trim($button->textContent)) || $button->hasAttribute('value');
        $has_aria = $button->hasAttribute('aria-label') || $button->hasAttribute('aria-labelledby');

        if (!$has_text && !$has_aria) {
            $unlabeled++;
        }
    }

    if ($buttons->length === 0) {
        return ['status' => 'pass', 'wcag' => '4.1.2 (A)', 'description' => 'Button labels', 'message' => 'No buttons found on this page.'];
    }

    if ($unlabeled === 0) {
        return ['status' => 'pass', 'wcag' => '4.1.2 (A)', 'description' => 'Button labels', 'message' => 'All ' . $buttons->length . ' buttons have accessible labels.'];
    } else {
        return ['status' => 'fail', 'wcag' => '4.1.2 (A)', 'description' => 'Button labels', 'message' => $unlabeled . ' out of ' . $buttons->length . ' buttons are missing accessible labels.'];
    }
}