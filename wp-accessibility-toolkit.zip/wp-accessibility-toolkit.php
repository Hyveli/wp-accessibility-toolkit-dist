<?php
/**
 * Plugin Name: WP Accessibility Toolkit
 * Plugin URI: https://github.com/hyveli/wp-accessibility-toolkit
 * Description: Implements WCAG 2.1 AA accessibility best practices site-wide with one-click toggles.
 * Version: 1.0.8
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Author: Kara Concepcion
 * Author URI: https://github.com/hyveli
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-accessibility-toolkit
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('WPAT_VERSION', '1.0.8');
define('WPAT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPAT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/hyveli/wp-accessibility-toolkit-dist/main/release.json',
            __FILE__,
            'wp-accessibility-toolkit'
        );

        // Debug: Check every 60 seconds instead of 12 hours
        $updateChecker->checkForUpdates();

        // Debug: Show update checker is active
        add_action('admin_notices', function() {
            echo '<div class="notice notice-info"><p>✅ Update checker is ACTIVE and loaded!</p></div>';
        });
    }
} else {
    // Debug: Show vendor is missing
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p>❌ Update checker NOT loaded - vendor/autoload.php is missing!</p></div>';
    });
}

// Activation hook
register_activation_hook(__FILE__, 'wpat_activate');
function wpat_activate() {
    // Set default options on activation
    add_option('wpat_skip_nav', true);
    add_option('wpat_focus_styles', true);
    add_option('wpat_lang_attr', true);
    flush_rewrite_rules();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'wpat_deactivate');
function wpat_deactivate() {
    flush_rewrite_rules();
}

// ============================================
// ACCESSIBILITY FEATURES
// ============================================

// Skip Navigation Link (WCAG 2.4.1 - Bypass Blocks)
add_action('wp_body_open', 'wpat_skip_navigation', 1);
function wpat_skip_navigation() {
    if (!get_option('wpat_skip_nav', true)) {
        return;
    }

    $label = 'Skip to main content';
    $target = '#main-content';

    echo '<a href="' . esc_attr($target) . '" class="wpat-skip-nav">' . esc_html($label) . '</a>';
}

// Add skip nav and focus styles CSS
add_action('wp_head', 'wpat_accessibility_styles', 1);
function wpat_accessibility_styles() {
    if (!get_option('wpat_skip_nav', true) && !get_option('wpat_focus_styles', true)) {
        return;
    }
    ?>
    <style id="wpat-a11y-styles">
        /* Skip Navigation Link */
        .wpat-skip-nav {
            position: absolute;
            top: -100%;
            left: 1rem;
            z-index: 10000;
            padding: 0.75rem 1.25rem;
            background: #000;
            color: #fff;
            text-decoration: none;
            border-radius: 0 0 4px 4px;
            font-size: 1rem;
            font-weight: 600;
        }
        .wpat-skip-nav:focus {
            top: 0;
        }

        /* Enhanced Focus Styles (WCAG 2.4.7 - Focus Visible) */
        *:focus-visible {
            outline: 3px solid #005FCC !important;
            outline-offset: 3px !important;
        }

        /* Ensure skip nav is always visible when focused */
        .wpat-skip-nav:focus-visible {
            outline: 3px solid #fff !important;
            outline-offset: 2px !important;
        }
    </style>
    <?php
}

// Add id="main-content" to main content area if it doesn't exist
add_filter('the_content', 'wpat_ensure_main_id', 1);
function wpat_ensure_main_id($content) {
    static $main_id_added = false;

    if (!$main_id_added && get_option('wpat_skip_nav', true)) {
        $content = '<div id="main-content" tabindex="-1"></div>' . $content;
        $main_id_added = true;
    }

    return $content;
}

// Page Titles Check (WCAG 2.4.2 - Page Titled)
add_action('wp_head', 'wpat_check_page_title', 1);
function wpat_check_page_title() {
    if (!get_option('wpat_page_titles', false)) {
        return;
    }

    // WordPress handles page titles well by default, but we can enhance
    add_filter('document_title_separator', function($sep) {
        return '|';
    });

    // Ensure title is descriptive
    add_filter('document_title_parts', function($title) {
        if (empty($title['title'])) {
            $title['title'] = get_the_title() ?: 'Untitled Page';
        }
        return $title;
    });
}

// ARIA Landmark Roles (WCAG 1.3.1 - Info and Relationships)
add_action('template_redirect', 'wpat_landmark_roles_buffer');
function wpat_landmark_roles_buffer() {
    if (!get_option('wpat_landmark_roles', false)) {
        return;
    }

    ob_start('wpat_add_landmark_roles');
}

function wpat_add_landmark_roles($html) {
    // Only process HTML responses
    if (!is_string($html) || empty($html)) {
        return $html;
    }

    // Add role attributes if missing
    $replacements = [
        '/<header(?![^>]*role=)/i' => '<header role="banner"',
        '/<main(?![^>]*role=)/i'   => '<main role="main"',
        '/<footer(?![^>]*role=)/i' => '<footer role="contentinfo"',
        '/<nav(?![^>]*role=)/i'    => '<nav role="navigation"',
    ];

    foreach ($replacements as $pattern => $replacement) {
        $html = preg_replace($pattern, $replacement, $html);
    }

    return $html;
}

add_action('shutdown', 'wpat_flush_landmark_buffer');
function wpat_flush_landmark_buffer() {
    if (get_option('wpat_landmark_roles', false) && ob_get_level() > 0) {
        ob_end_flush();
    }
}

// Heading Structure Check (WCAG 1.3.1)
add_action('wp_footer', 'wpat_check_heading_structure');
function wpat_check_heading_structure() {
    if (!get_option('wpat_heading_structure', false) || !current_user_can('manage_options')) {
        return;
    }

    // Add inline JavaScript to check heading structure (admin only)
    ?>
    <script>
    (function() {
        const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6'));
        const levels = headings.map(h => parseInt(h.tagName.substr(1)));
        let issues = [];

        // Check for multiple H1s
        const h1Count = levels.filter(l => l === 1).length;
        if (h1Count > 1) {
            issues.push('Multiple H1 tags found (' + h1Count + '). Each page should have only one H1.');
        }

        // Check for skipped levels
        for (let i = 1; i < levels.length; i++) {
            if (levels[i] - levels[i-1] > 1) {
                issues.push('Heading level skipped: H' + levels[i-1] + ' to H' + levels[i]);
            }
        }

        if (issues.length > 0 && typeof console !== 'undefined') {
            console.warn('⚠️ WP Accessibility Toolkit - Heading Structure Issues:');
            issues.forEach(issue => console.warn('  - ' + issue));
        }
    })();
    </script>
    <?php
}

// Form Labels Check (WCAG 1.3.1, 3.3.2)
add_action('wp_footer', 'wpat_check_form_labels');
function wpat_check_form_labels() {
    if (!get_option('wpat_form_labels', false) || !current_user_can('manage_options')) {
        return;
    }

    // Add inline JavaScript to check form labels (admin only)
    ?>
    <script>
    (function() {
        const inputs = document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]), textarea, select');
        let unlabeledInputs = [];

        inputs.forEach(input => {
            const hasLabel = input.labels && input.labels.length > 0;
            const hasAriaLabel = input.getAttribute('aria-label');
            const hasAriaLabelledby = input.getAttribute('aria-labelledby');
            const hasTitle = input.getAttribute('title');

            if (!hasLabel && !hasAriaLabel && !hasAriaLabelledby && !hasTitle) {
                unlabeledInputs.push(input);
            }
        });

        if (unlabeledInputs.length > 0 && typeof console !== 'undefined') {
            console.warn('⚠️ WP Accessibility Toolkit - Form Label Issues:');
            console.warn('  Found ' + unlabeledInputs.length + ' unlabeled form inputs:', unlabeledInputs);
        }
    })();
    </script>
    <?php
}

// ============================================
// ADMIN INTERFACE
// ============================================

// Add admin menu
add_action('admin_menu', 'wpat_add_admin_menu');
function wpat_add_admin_menu() {
    add_menu_page(
        'Accessibility',
        'Accessibility',
        'manage_options',
        'wp-accessibility-toolkit',
        'wpat_admin_page',
        'dashicons-shield',
        30
    );

    add_submenu_page(
        'wp-accessibility-toolkit',
        'Settings',
        'Settings',
        'manage_options',
        'wpat-settings',
        'wpat_settings_page'
    );
}

// Register settings
add_action('admin_init', 'wpat_register_settings');
function wpat_register_settings() {
    register_setting('wpat_settings_group', 'wpat_skip_nav');
    register_setting('wpat_settings_group', 'wpat_focus_styles');
    register_setting('wpat_settings_group', 'wpat_lang_attr');
    register_setting('wpat_settings_group', 'wpat_page_titles');
    register_setting('wpat_settings_group', 'wpat_heading_structure');
    register_setting('wpat_settings_group', 'wpat_form_labels');
    register_setting('wpat_settings_group', 'wpat_landmark_roles');
}

// Dashboard page
function wpat_admin_page() {
    $active_features = array_filter([
        get_option('wpat_skip_nav', true) ? 'Skip Navigation' : null,
        get_option('wpat_focus_styles', true) ? 'Focus Styles' : null,
        get_option('wpat_lang_attr', true) ? 'Language Attribute' : null,
        get_option('wpat_page_titles', false) ? 'Page Titles' : null,
        get_option('wpat_heading_structure', false) ? 'Heading Structure' : null,
        get_option('wpat_form_labels', false) ? 'Form Labels' : null,
        get_option('wpat_landmark_roles', false) ? 'ARIA Landmarks' : null,
    ]);
    ?>
    <div class="wrap">
        <h1>🛡️ WP Accessibility Toolkit</h1>
        <p><strong>Version:</strong> <?php echo WPAT_VERSION; ?> | <strong>Compliance Level:</strong> WCAG 2.2 Level A</p>

        <div class="card" style="max-width: 800px;">
            <h2>Active Features (<?php echo count($active_features); ?>)</h2>
            <?php if (count($active_features) > 0): ?>
                <ul style="line-height: 1.8;">
                    <?php foreach ($active_features as $feature): ?>
                        <li>✅ <?php echo esc_html($feature); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No features currently enabled. Go to <a href="<?php echo admin_url('admin.php?page=wpat-settings'); ?>">Settings</a> to enable features.</p>
            <?php endif; ?>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px; background: #f0f6fc; border-left: 4px solid #005FCC;">
            <h3>🧪 Quick Start</h3>
            <ol>
                <li>Go to <a href="<?php echo admin_url('admin.php?page=wpat-settings'); ?>">Settings</a> to enable accessibility features</li>
                <li>Test skip navigation by pressing <kbd>Tab</kbd> on your homepage</li>
                <li>Navigate with keyboard to see enhanced focus indicators</li>
            </ol>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>📋 What's New in v1.0.8</h3>
            <ul>
                <li>Added WCAG 2.2 Level A compliance features</li>
                <li>Settings page with toggle controls</li>
                <li>Automatic update system</li>
            </ul>
        </div>
    </div>
    <style>
        kbd {
            background: #f4f4f4;
            border: 1px solid #ccc;
            border-radius: 3px;
            padding: 2px 6px;
            font-family: monospace;
            font-size: 0.9em;
        }
    </style>
    <?php
}

// Settings page
function wpat_settings_page() {
    if (isset($_POST['wpat_settings_submit'])) {
        check_admin_referer('wpat_settings_save', 'wpat_settings_nonce');

        // Save all settings
        update_option('wpat_skip_nav', isset($_POST['wpat_skip_nav']) ? 1 : 0);
        update_option('wpat_focus_styles', isset($_POST['wpat_focus_styles']) ? 1 : 0);
        update_option('wpat_lang_attr', isset($_POST['wpat_lang_attr']) ? 1 : 0);
        update_option('wpat_page_titles', isset($_POST['wpat_page_titles']) ? 1 : 0);
        update_option('wpat_heading_structure', isset($_POST['wpat_heading_structure']) ? 1 : 0);
        update_option('wpat_form_labels', isset($_POST['wpat_form_labels']) ? 1 : 0);
        update_option('wpat_landmark_roles', isset($_POST['wpat_landmark_roles']) ? 1 : 0);

        echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Accessibility Settings</h1>
        <p>Enable or disable individual WCAG 2.2 Level A compliance features.</p>

        <form method="post" action="">
            <?php wp_nonce_field('wpat_settings_save', 'wpat_settings_nonce'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wpat_skip_nav">Skip Navigation Link</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_skip_nav" id="wpat_skip_nav" value="1" <?php checked(get_option('wpat_skip_nav', true)); ?>>
                            Enable skip navigation link (WCAG 2.4.1)
                        </label>
                        <p class="description">Adds a "Skip to main content" link for keyboard users. <strong>Disable if your theme already includes this.</strong></p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_focus_styles">Enhanced Focus Styles</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_focus_styles" id="wpat_focus_styles" value="1" <?php checked(get_option('wpat_focus_styles', true)); ?>>
                            Enable visible focus indicators (WCAG 2.4.7)
                        </label>
                        <p class="description">Adds blue outline to all focusable elements for keyboard navigation.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_lang_attr">Language Attribute</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_lang_attr" id="wpat_lang_attr" value="1" <?php checked(get_option('wpat_lang_attr', true)); ?>>
                            Ensure HTML lang attribute (WCAG 3.1.1)
                        </label>
                        <p class="description">Ensures the &lt;html&gt; tag has a lang attribute for screen readers.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_page_titles">Page Titles</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_page_titles" id="wpat_page_titles" value="1" <?php checked(get_option('wpat_page_titles', false)); ?>>
                            Ensure descriptive page titles (WCAG 2.4.2)
                        </label>
                        <p class="description">Checks that every page has a unique &lt;title&gt; tag.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_heading_structure">Heading Structure</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_heading_structure" id="wpat_heading_structure" value="1" <?php checked(get_option('wpat_heading_structure', false)); ?>>
                            Check heading hierarchy (WCAG 1.3.1)
                        </label>
                        <p class="description">Warns if heading levels are skipped (e.g., H2 → H4).</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_form_labels">Form Labels</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_form_labels" id="wpat_form_labels" value="1" <?php checked(get_option('wpat_form_labels', false)); ?>>
                            Ensure form inputs have labels (WCAG 1.3.1, 3.3.2)
                        </label>
                        <p class="description">Checks that all form inputs have associated labels.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="wpat_landmark_roles">ARIA Landmarks</label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="wpat_landmark_roles" id="wpat_landmark_roles" value="1" <?php checked(get_option('wpat_landmark_roles', false)); ?>>
                            Add ARIA landmark roles (WCAG 1.3.1)
                        </label>
                        <p class="description">Adds role attributes to &lt;header&gt;, &lt;main&gt;, &lt;footer&gt; if missing. <strong>May impact performance.</strong></p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" name="wpat_settings_submit" class="button button-primary" value="Save Settings">
            </p>
        </form>
    </div>
    <?php
}