require_once __DIR__ . '/vendor/autoload.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$updateChecker = PucFactory::buildUpdateChecker(
    'https://raw.githubusercontent.com/hyveli/wp-cookie-consent-dist/main/release.json',
    __FILE__,
    'wp-cookie-consent'
);